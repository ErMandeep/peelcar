
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
		<li class="active">
			<a href="#"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
		</li>
		<li class="treeview">
			<a href="#"><i class="fa fa-dashboard"></i> <span>Application</span>
				<span class="pull-right-container">
					<i class="fa fa-angle-left pull-right"></i>
				</span>
			</a>
			<ul class="treeview-menu">
				<li><a href="view-application.php"><i class="fa fa-circle-o"></i> View Applications</a></li>
				<li><a href="create-application.php"><i class="fa fa-circle-o"></i> Create New Application</a></li>
				<li><a href="#"><i class="fa fa-circle-o"></i> View Claims</a></li>
			</ul>
		</li>
		<li><a href="#"><i class="fa fa-dashboard"></i> <span>Gap Insurance</span></a></li>
		<li><a href="#"><i class="fa fa-dashboard"></i> <span>User</span></a></li>
		<li><a href="#"><i class="fa fa-dashboard"></i> <span>Account Setting</span></a></li>
		<li><a href="#"><i class="fa fa-dashboard"></i> <span>Help</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>